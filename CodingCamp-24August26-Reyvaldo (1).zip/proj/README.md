# To-Do List Life Dashboard
Buka `index.html` di browser. Deploy: GitHub Pages (Settings > Pages > branch main / root).
