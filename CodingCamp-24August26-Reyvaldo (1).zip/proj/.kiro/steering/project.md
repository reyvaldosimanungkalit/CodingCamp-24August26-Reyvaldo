# To-Do List Life Dashboard
Constraints: HTML + CSS + Vanilla JS only (no frameworks, no backend). Data in Local Storage.
Folder rules: 1 CSS file in css/, 1 JS file in js/. Modern browsers. Clean, minimal, readable.
MVP: Greeting (time/date), Focus Timer (25 min, start/stop/reset), To-Do (add/edit/done/delete, saved), Quick Links (saved).
Challenges implemented: Light/Dark mode, Custom name, Change Pomodoro time, Prevent duplicate tasks, Sort tasks.
