// To-Do List Life Dashboard - Vanilla JS
const $ = id => document.getElementById(id);
const load = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };
const save = (k, v) => localStorage.setItem(k, JSON.stringify(v));

/* ===== Greeting, Clock, Name ===== */
let userName = load('name', '');
function renderName() { $('nameShow').textContent = userName || 'Teman'; }
function tick() {
  const n = new Date(), h = n.getHours();
  $('clock').textContent = n.toLocaleTimeString('id-ID', { hour12: false }).replace(/\./g, ':');
  $('date').textContent = n.toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  $('greet').textContent = h < 11 ? 'Selamat Pagi' : h < 15 ? 'Selamat Siang' : h < 18 ? 'Selamat Sore' : 'Selamat Malam';
}
$('nameBtn').onclick = () => { userName = $('nameInput').value.trim(); save('name', userName); $('nameInput').value = ''; renderName(); };
$('nameInput').onkeydown = e => e.key === 'Enter' && $('nameBtn').click();
setInterval(tick, 1000); tick(); renderName();

/* ===== Theme ===== */
function applyTheme(t) { document.documentElement.dataset.theme = t; $('themeBtn').textContent = t === 'dark' ? '☀️' : '🌙'; }
let theme = load('theme', 'light'); applyTheme(theme);
$('themeBtn').onclick = () => { theme = theme === 'dark' ? 'light' : 'dark'; save('theme', theme); applyTheme(theme); };

/* ===== Focus Timer ===== */
let minutes = load('minutes', 25), left = minutes * 60, iv = null, endAt = 0;
const fmt = s => String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
function showTimer() { $('timer').textContent = fmt(left); document.title = (iv ? fmt(left) + ' - ' : '') + 'Life Dashboard'; }
function stopTimer() { clearInterval(iv); iv = null; showTimer(); }
$('startBtn').onclick = () => {
  if (iv || left <= 0) return;
  endAt = Date.now() + left * 1000;
  iv = setInterval(() => {
    left = Math.max(0, Math.round((endAt - Date.now()) / 1000));
    if (left === 0) { stopTimer(); alert('⏰ Waktu fokus selesai! Saatnya istirahat.'); }
    showTimer();
  }, 250);
};
$('stopBtn').onclick = stopTimer;
$('resetBtn').onclick = () => { stopTimer(); left = minutes * 60; showTimer(); };
$('setBtn').onclick = () => {
  const v = parseInt($('minInput').value, 10);
  if (!v || v < 1 || v > 180) return alert('Masukkan 1 - 180 menit.');
  minutes = v; save('minutes', v); stopTimer(); left = v * 60; showTimer();
};
$('minInput').value = minutes; showTimer();

/* ===== Tasks ===== */
let tasks = load('tasks', []), sortMode = load('sort', 'new');
const flash = t => { $('msg').textContent = t; setTimeout(() => $('msg').textContent = '', 2500); };
function renderTasks() {
  let list = tasks.slice();
  if (sortMode === 'new') list.reverse();
  if (sortMode === 'az') list.sort((a, b) => a.text.localeCompare(b.text));
  if (sortMode === 'za') list.sort((a, b) => b.text.localeCompare(a.text));
  if (sortMode === 'undone') list.sort((a, b) => a.done - b.done);
  const ul = $('taskList'); ul.innerHTML = '';
  if (!list.length) ul.innerHTML = '<li class="empty">Belum ada tugas 🎉</li>';
  list.forEach(t => {
    const li = document.createElement('li'); if (t.done) li.className = 'done';
    const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = t.done;
    cb.onchange = () => { t.done = cb.checked; save('tasks', tasks); renderTasks(); };
    const sp = document.createElement('span'); sp.textContent = t.text;
    const ed = document.createElement('button'); ed.className = 'mini edit'; ed.textContent = 'Edit';
    ed.onclick = () => {
      const v = prompt('Edit tugas:', t.text); if (v === null) return;
      const nv = v.trim(); if (!nv) return flash('Tugas tidak boleh kosong.');
      if (tasks.some(x => x !== t && x.text.toLowerCase() === nv.toLowerCase())) return flash('Tugas sudah ada!');
      t.text = nv; save('tasks', tasks); renderTasks();
    };
    const del = document.createElement('button'); del.className = 'mini del'; del.textContent = 'Delete';
    del.onclick = () => { tasks = tasks.filter(x => x !== t); save('tasks', tasks); renderTasks(); };
    li.append(cb, sp, ed, del); ul.appendChild(li);
  });
}
function addTask() {
  const text = $('taskInput').value.trim();
  if (!text) return flash('Tulis tugas dulu ya.');
  if (tasks.some(t => t.text.toLowerCase() === text.toLowerCase())) return flash('Tugas duplikat tidak diperbolehkan!');
  tasks.push({ id: Date.now(), text, done: false }); save('tasks', tasks);
  $('taskInput').value = ''; renderTasks();
}
$('addTask').onclick = addTask;
$('taskInput').onkeydown = e => e.key === 'Enter' && addTask();
$('sortSel').value = sortMode;
$('sortSel').onchange = e => { sortMode = e.target.value; save('sort', sortMode); renderTasks(); };
renderTasks();

/* ===== Quick Links ===== */
let links = load('links', [
  { name: 'Google', url: 'https://google.com' },
  { name: 'Gmail', url: 'https://mail.google.com' },
  { name: 'Calendar', url: 'https://calendar.google.com' }
]);
function renderLinks() {
  const box = $('links'); box.innerHTML = '';
  links.forEach((l, i) => {
    const d = document.createElement('div'); d.className = 'link';
    const a = document.createElement('a'); a.href = l.url; a.target = '_blank'; a.rel = 'noopener'; a.textContent = l.name;
    const x = document.createElement('button'); x.textContent = '✕'; x.title = 'Hapus';
    x.onclick = () => { links.splice(i, 1); save('links', links); renderLinks(); };
    d.append(a, x); box.appendChild(d);
  });
}
$('addLink').onclick = () => {
  const name = $('linkName').value.trim(); let url = $('linkUrl').value.trim();
  if (!name || !url) return alert('Isi nama dan URL link.');
  if (!/^https?:\/\//i.test(url)) url = 'https://' + url;
  try { new URL(url); } catch { return alert('URL tidak valid.'); }
  links.push({ name, url }); save('links', links);
  $('linkName').value = $('linkUrl').value = ''; renderLinks();
};
renderLinks();
